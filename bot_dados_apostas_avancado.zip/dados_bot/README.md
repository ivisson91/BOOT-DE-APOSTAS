# Bot de Dados com Estatísticas Avançadas

Este bot realiza análises estatísticas detalhadas a partir de uma planilha de resultados esportivos (CSV), e sugere apostas com base nas estatísticas dos dois times informados.

## Estatísticas calculadas:
- Últimos 5 jogos
- Gols marcados e sofridos
- Over 1.5 / Over 2.5 / Over 3.5
- Ambos Marcam (BTTS)
- Desempenho como mandante/visitante
- Head-to-head

## Como usar
1. Instale as dependências:
   ```
   pip install -r requirements.txt
   ```

2. Substitua ou edite o arquivo `dados/serie_a.csv` com suas partidas.

3. Execute:
   ```
   python bot_dados.py
   ```

4. Digite dois times, exemplo:
   ```
   Napoli x Empoli
   ```
