import pandas as pd

def analisar_time(df, time, local):
    if local == 'home':
        jogos = df[df['home_team'] == time]
        gols_marcados = jogos['home_goals']
        gols_sofridos = jogos['away_goals']
    else:
        jogos = df[df['away_team'] == time]
        gols_marcados = jogos['away_goals']
        gols_sofridos = jogos['home_goals']

    ultimos5 = jogos.tail(5)
    total_jogos = len(jogos)

    over15 = sum((gols_marcados + gols_sofridos) > 1.5)
    over25 = sum((gols_marcados + gols_sofridos) > 2.5)
    over35 = sum((gols_marcados + gols_sofridos) > 3.5)
    btts = sum((gols_marcados > 0) & (gols_sofridos > 0))

    if local == 'home':
        vitorias = sum(jogos['home_goals'] > jogos['away_goals'])
    else:
        vitorias = sum(jogos['away_goals'] > jogos['home_goals'])

    return {
        'jogos': total_jogos,
        'gols_marcados': gols_marcados.sum(),
        'gols_sofridos': gols_sofridos.sum(),
        'over15_pct': round((over15 / total_jogos) * 100, 1),
        'over25_pct': round((over25 / total_jogos) * 100, 1),
        'over35_pct': round((over35 / total_jogos) * 100, 1),
        'btts_pct': round((btts / total_jogos) * 100, 1),
        'vitorias': vitorias,
        'ultimos5': ultimos5
    }

def confronto_direto(df, time1, time2):
    h2h = df[((df['home_team'] == time1) & (df['away_team'] == time2)) | ((df['home_team'] == time2) & (df['away_team'] == time1))]
    return h2h.tail(5)

def main():
    df = pd.read_csv('dados/serie_a.csv')
    entrada = input("Digite o confronto (ex: Napoli x Empoli): ")
    time1, time2 = [t.strip() for t in entrada.split('x')]

    print(f"\n🔍 Estatísticas para {time1} (como mandante):")
    estat1 = analisar_time(df, time1, 'home')
    for k, v in estat1.items():
        if k != 'ultimos5':
            print(f"- {k.replace('_', ' ').capitalize()}: {v}")

    print(f"\n🔍 Estatísticas para {time2} (como visitante):")
    estat2 = analisar_time(df, time2, 'away')
    for k, v in estat2.items():
        if k != 'ultimos5':
            print(f"- {k.replace('_', ' ').capitalize()}: {v}")

    print(f"\n📅 Últimos confrontos diretos entre {time1} e {time2}:")
    h2h = confronto_direto(df, time1, time2)
    print(h2h[['date', 'home_team', 'away_team', 'home_goals', 'away_goals']])

    print("\n📌 Sugestão com base nas estatísticas:")
    if estat1['over25_pct'] > 60 and estat2['over25_pct'] > 60:
        print("👉 Sugestão: Over 2.5 gols")
    elif estat1['btts_pct'] > 50 and estat2['btts_pct'] > 50:
        print("👉 Sugestão: Ambos Marcam (BTTS)")
    elif estat1['vitorias'] > estat2['vitorias']:
        print(f"👉 Sugestão: Vitória do {time1}")
    else:
        print("👉 Sugestão: Jogo equilibrado ou Empate")

if __name__ == '__main__':
    main()
